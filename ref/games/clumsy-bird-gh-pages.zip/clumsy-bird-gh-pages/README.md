Clumsy Bird
===========

[![Flattr this git
repo](http://api.flattr.com/button/flattr-badge-large.png)](https://flattr.com/submit/auto?user_id=ellisonleao&url=https://github.com/ellisonleao/clumsy-bird&title=Clumsy-Bird&language=javascript&tags=github&category=software)

A MelonJS made "Flappy Bird" clone.

![](http://i.imgur.com/Slbvt65.png)

Play online at http://ellisonleao.github.io/clumsy-bird/

## Running Locally

Just type on your shell:

	make run

and open your browser on http://localhost:8001/
